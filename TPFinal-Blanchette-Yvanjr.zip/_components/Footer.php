  <footer class="bg-[#738C69]/30 text-center py-4 px-[5vw]">
    <p class="text-sm md:text-base font-medium">&copy; Copyright <?= date('Y') ?> - <span class="text-lg md:text-xl">Évasion Camping</span> - Tous droits réservés</p>
    <p class="block text-xs">Une création de Yvan jr Blanchette,<br class="md:hidden"> dans le cadre du cours d'infrastructure web</p>
    <p class="leading-none text-xs">de l'AEC en développement Web du cégep de Trois-Rivières</p>

  </footer>

  </body>

  </html>