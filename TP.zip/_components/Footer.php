  <footer class="bg-[#738C69]/30 text-center p-4">
    <p>&copy; Copyright <?= date('Y') ?> - Évasion Camping - Tous droits réservés</p>
    <p class="block text-xs">Une création de Yvan jr Blanchette dans le cadre du cours d'infrastructure web</p>
    <p class="leading-none text-xs">de l'AEC en développement Web du cégep de Trois-Rivières</p>

  </footer>

  </body>

  </html>